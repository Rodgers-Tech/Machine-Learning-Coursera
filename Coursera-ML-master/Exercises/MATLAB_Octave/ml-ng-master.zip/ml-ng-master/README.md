# Machine Learning with Octave

This repo contains my solutions to the programming exercises of Andrew Ng's Machine Learning course on Coursera. Some major machine learning algorithms including linear regression, logistic regression, support vector machines, k nearest neighbors, neural networks, and recommender system are implemented with **Octave**. 
