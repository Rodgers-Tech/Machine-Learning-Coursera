


warmUpExercise <- function(dimension){
	return (diag(dimension));
}

warmUpExercise(5);